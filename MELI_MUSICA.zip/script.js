const audio = document.getElementById("audio");
const playButton = document.getElementById("playButton");
const previousButton = document.getElementById("previousButton");
const nextButton = document.getElementById("nextButton");
const shuffleButton = document.getElementById("shuffleButton");
const repeatButton = document.getElementById("repeatButton");
const progress = document.getElementById("progress");
const volume = document.getElementById("volume");
const currentTime = document.getElementById("currentTime");
const duration = document.getElementById("duration");
const nowTitle = document.getElementById("nowTitle");
const nowArtist = document.getElementById("nowArtist");
const playlist = document.getElementById("playlist");
const songCount = document.getElementById("songCount");
const searchInput = document.getElementById("searchInput");
const themeButton = document.getElementById("themeButton");
const cover = document.getElementById("cover");

let songs = [];
let currentIndex = 0;
let shuffle = false;
let repeat = false;

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  const min = Math.floor(seconds / 60);
  const sec = Math.floor(seconds % 60);
  return `${min}:${String(sec).padStart(2, "0")}`;
}

function loadSong(index, autoplay = false) {
  if (!songs[index]) return;

  currentIndex = index;
  const song = songs[index];

  audio.src = song.url;
  nowTitle.textContent = song.title;
  nowArtist.textContent = song.artist;
  cover.textContent = song.emoji || "🎵";
  progress.value = 0;
  currentTime.textContent = "0:00";
  duration.textContent = "0:00";

  renderPlaylist(searchInput.value);

  if (autoplay) {
    audio.play().catch(() => {});
  }
}

function playPause() {
  if (!songs.length) return;

  if (audio.paused) {
    audio.play().catch(() => {});
  } else {
    audio.pause();
  }
}

function nextSong() {
  if (!songs.length) return;

  if (shuffle && songs.length > 1) {
    let next;
    do {
      next = Math.floor(Math.random() * songs.length);
    } while (next === currentIndex);
    currentIndex = next;
  } else {
    currentIndex = (currentIndex + 1) % songs.length;
  }

  loadSong(currentIndex, true);
}

function previousSong() {
  if (!songs.length) return;

  if (audio.currentTime > 3) {
    audio.currentTime = 0;
    return;
  }

  currentIndex = (currentIndex - 1 + songs.length) % songs.length;
  loadSong(currentIndex, true);
}

function renderPlaylist(filter = "") {
  const query = filter.trim().toLowerCase();
  playlist.innerHTML = "";

  const visible = songs
    .map((song, index) => ({ song, index }))
    .filter(({ song }) => song.title.toLowerCase().includes(query));

  songCount.textContent = `${songs.length} ${songs.length === 1 ? "canción" : "canciones"}`;

  if (!visible.length) {
    playlist.innerHTML = `<div class="empty">${
      songs.length ? "No se encontraron canciones." : "Todavía no hay canciones."
    }</div>`;
    return;
  }

  visible.forEach(({ song, index }) => {
    const item = document.createElement("div");
    item.className = "song" + (index === currentIndex ? " active" : "");

    item.innerHTML = `
      <div class="song-number">${index + 1}</div>
      <div class="song-icon">${song.emoji || "🎵"}</div>
      <div class="song-name">
        <strong></strong>
        <small></small>
      </div>
    `;

    item.querySelector("strong").textContent = song.title;
    item.querySelector("small").textContent = song.artist;

    item.addEventListener("click", () => loadSong(index, true));
    playlist.appendChild(item);
  });
}

playButton.addEventListener("click", playPause);
nextButton.addEventListener("click", nextSong);
previousButton.addEventListener("click", previousSong);

shuffleButton.addEventListener("click", () => {
  shuffle = !shuffle;
  shuffleButton.classList.toggle("active", shuffle);
});

repeatButton.addEventListener("click", () => {
  repeat = !repeat;
  repeatButton.classList.toggle("active", repeat);
});

volume.addEventListener("input", () => {
  audio.volume = Number(volume.value);
});

progress.addEventListener("input", () => {
  if (audio.duration) {
    audio.currentTime = (Number(progress.value) / 100) * audio.duration;
  }
});

searchInput.addEventListener("input", () => renderPlaylist(searchInput.value));

audio.addEventListener("play", () => {
  playButton.textContent = "⏸️";
});

audio.addEventListener("pause", () => {
  playButton.textContent = "▶️";
});

audio.addEventListener("timeupdate", () => {
  if (!audio.duration) return;
  progress.value = (audio.currentTime / audio.duration) * 100;
  currentTime.textContent = formatTime(audio.currentTime);
});

audio.addEventListener("loadedmetadata", () => {
  duration.textContent = formatTime(audio.duration);
});

audio.addEventListener("ended", () => {
  if (repeat) {
    audio.currentTime = 0;
    audio.play().catch(() => {});
  } else {
    nextSong();
  }
});

themeButton.addEventListener("click", () => {
  document.body.classList.toggle("light");
  themeButton.textContent = document.body.classList.contains("light") ? "🌙" : "☀️";
});

// Las canciones se cargan desde la carpeta "music".
// Agrega tus MP3 a esa carpeta y escribe sus nombres aquí.
songs = [
  // Ejemplo:
  // {
  //   title: "Mi canción",
  //   artist: "MELI MÚSICA",
  //   url: "music/mi-cancion.mp3",
  //   emoji: "🎵"
  // }
];

renderPlaylist();
